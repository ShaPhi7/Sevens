package Shaun.sevens.Game;

public enum CardSuit {
	DIAMONDS("Diamonds"),
	SPADES("Spades"),
	HEARTS("Hearts"),
	CLUBS("Clubs");
	//TODO - would be nice to change this to show the actual symbol, but keeping simple here.
	
	private final String cardSuitText;

	CardSuit(String cardSuitText) {
		this.cardSuitText = cardSuitText;
	}
	
	public String getCardSuitText() {
		return cardSuitText;
	}
}
